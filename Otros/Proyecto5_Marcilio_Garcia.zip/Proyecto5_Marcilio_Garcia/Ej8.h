#include <stdio.h>


/*Defino una estructura compuesta por dos enteros,
para que la "función" del algoritmo de la división pueda
devolver cociente y resto*/
struct divi
{
      int cociente;
      int resto;
};

/*Escribo algDiv que devolverá un "struct divi"*/
struct divi algDiv(int X,int Y){
	int q=0;
	int r=X;
	struct divi resul;
	while (r>=Y){
		q=q+1;
		r=r-Y;
	}
	resul.cociente=q;
	resul.resto=r;
	return resul;

}

int main8()
{
	int n=0;
	int d=0;
    system("clear");
    printf("****************************\n");
  	printf("* Algoritmo de la Division *\n");
  	printf("****************************\n");
    printf("\nIngrese un numero:\n");
    scanf("%d",&n);
    printf("\nIngrese el divisor:\n");
    scanf("%d",&d);
    /*llamo a cada parte del struct con un punto seguido de
    la parte que necesito*/
    printf ("El cociente de la division es %d\n", algDiv(n,d).cociente);
    printf ("\nEl resto de la division es %d\n\n", algDiv(n,d).resto);
        getchar();
        getchar();
return 0;
}
