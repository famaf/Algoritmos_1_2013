#include <stdio.h>



/*Defino un operador Max con macros*/
#define MAX(x, y) (((x) > (y)) ? (x) : (y))

void main9b(int arreglo[], int N)
{
	int r=-2147483648 ;
	int s=arreglo[0];
	int n=1;
    system("clear");
    if (N>0){
	while (n<N){
		r=MAX(r,s - arreglo[n]);
        s=MAX(s,arreglo[n]);
        n++;
	    }
    printf("La m�xima diferencia entre dos elementos del arreglo es: %d\n",r);
    }
    else {printf("El arreglo esta vacio!!");}
    getchar();
    getchar();

}
