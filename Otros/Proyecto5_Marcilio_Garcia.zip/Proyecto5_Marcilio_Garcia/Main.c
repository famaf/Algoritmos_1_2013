#include <stdio.h>
#include <stdlib.h>
#include "arrays.h"
#include "Ej1.h"
#include "Ej2.h"
#include "Ej3.h"
#include "Ej4.h"
#include "Ej5.h"
#include "Ej6.h"
#include "Ej7.h"
#include "Ej8.h"
#include "Ej9a.h"
#include "Ej9b.h"
#include "Ej9c.h"
#include "Ej9d.h"

/*defino 3 struct arreglo fuera de las funciones para poder usarlas de forma global
dicen que no es recomendable, pero no se me ocurri� otra forma */
struct arreglo arreglo1;/*el struct arreglo est� definido en arrays.h*/
struct arreglo arreglo2;/*consta de un arreglo y un n�mero que se manejar�*/
struct arreglo arreglo3;/*como la longitud, aunque estrictamente no lo sea.*/
/*a continuaci�n se declaran dos funciones que se desciben m�s abajo*/
void arreglos();
void main9d();

/*luego el cuerpo principal*/
int main(){
    int in;
    system("clear");
    printf("***************************************************************************\n");
    printf("*                           *  PROYECTO 5 *                               *\n");
    printf("*                           ***************                               *\n");
    printf("* ATENCION: Cree un Arreglo antes de usar los programas que lo requieran. *\n");
    printf("*                                                                         *\n");
    printf("* Elija un programa:                                                      *\n");
    printf("*                                                                         *\n");
    printf("* 1)  Ejercicio 1  (Menor x tal que x^3 + x >= N)                         *\n");
    printf("* 2)  Ejercicio 2  (Suma los elementos del arreglo)                       *\n");
    printf("* 3)  Ejercicio 3  (Maximo elemento del arreglo)                          *\n");
    printf("* 4)  Ejercicio 4  (Cantidad de elementos pares del arreglo)              *\n");
    printf("* 5)  Ejercicio 5  (Desviacion standard del arreglo)                      *\n");
    printf("* 6)  Ejercicio 6  (Posicion de un elemento en el arreglo)                *\n");
    printf("* 7)  Ejercicio 7  (Todos los elementos del arreglo son positivos?)       *\n");
    printf("* 8)  Ejercicio 8  (Algoritmo de la division)                             *\n");
    printf("* 9)  Ejercicio 9a (Fibonacci)                                            *\n");
    printf("* 10) Ejercicio 9b (Mayor diferencia entre dos elementos del arreglo)     *\n");
    printf("* 11) Ejercicio 9c (Cantidad de productos positivos del arreglo)          *\n");
    printf("* 12) Ejercicio 9d (Producto escalar entre los dos arreglos)              *\n");
    printf("*                                                                         *\n");
    printf("* 13) Crear/Ver el arreglo                                                *\n");
    printf("* 14) Salir                                                               *\n");
    printf("***************************************************************************\n");
    scanf("%d",&in);
    /*luego un if por cada opci�n, las funciones de cada ejercicio est�n en su archivo .h
    y est�n nombradas mainNumeroDeEjercicio.
    a las que usan arreglos se les pasa como argumentos arreglo1.arr que es el arreglo
    y arreglo1.len que es el length*/

    if (in==1){main1();main();}
    if (in==2){main2(arreglo1.arr,arreglo1.len);main();}
    if (in==3){main3(arreglo1.arr,arreglo1.len);main();}
    if (in==4){main4(arreglo1.arr,arreglo1.len);main();}
    if (in==5){main5(arreglo1.arr,arreglo1.len);main();}
    if (in==6){main6(arreglo1.arr,arreglo1.len);main();}
    if (in==7){main7(arreglo1.arr,arreglo1.len);main();}
    if (in==8){main8();main();}
    if (in==9){main9a();main();}
    if (in==10){main9b(arreglo1.arr,arreglo1.len);main();}
    if (in==11){main9c(arreglo1.arr,arreglo1.len);main();}
    if (in==12){main9d();main();}
    if (in==13){arreglos();}
    else {
    system("clear");
    }
return 0;
}
/*la ventana para el manejo del arreglo,
no es muy pr�ctico que est� por separado del main
pero queda muy cheto*/
void arreglos(){
    int in;
    system("clear");
    printf("****************************************************\n");
    printf("*          ***********                             *\n");
    printf("*          * ARREGLO *                             *\n");
    printf("*          ***********    1)Crear/Modificar        *\n");
    printf("*                         2)Ver                    *\n");
    printf("*                                                  *\n");
    printf("*                         3)Volver                 *\n");
    printf("*                                                  *\n");
    printf("*                                                  *\n");
    printf("****************************************************\n");
    scanf("%d",&in);

    if (in==1){arreglo1=crearArray();arreglos();}
    if (in==2){system ("clear");mostrarArray(arreglo1.arr,arreglo1.len);arreglos();}
    if (in==3){main();}
}

/*el main9d es distinto al resto ya que necesita un segundo arreglo
para hacer la multiplicaci�n*/
void main9d(){
system ("clear");
printf("El arreglo actual tiene los siguientes elementos:\n");
mostrarArray(arreglo1.arr,arreglo1.len);/*muestra el arreglo actual*/
printf("\nIngrese otro arreglo de %d elementos para la multiplicacion:\n",arreglo1.len);
/*dice de cuantos elementos debe ser elarreglo nuevo para que coincida*/
getchar();

arreglo2=crearArray();/*crea el arreglo nuevo*/
prodPun(arreglo1.arr,arreglo2.arr,arreglo1.len);/*llama a la funcion prodPun del archivo main9.h*/
}
