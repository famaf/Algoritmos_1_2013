#include <stdio.h>



void main9c(int arreglo[], int N )
{
   	int n=0;
   	int Pos=0;
   	int Neg=0;
   	int r=0;
   	system("clear");
	while (n<N){
		if (arreglo[n]>0){r=r+Pos;Pos=Pos+1;}
		else if (arreglo[n]<0){r=r+Neg;Neg=Neg+1;}
		else {r=r+n;Pos=Pos+1;}
           n++;
	}
	printf("La cantidad de productos positivos es: %d\n", r);
    getchar();
    getchar();
}
