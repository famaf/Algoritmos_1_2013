#include <stdio.h>


/*Esta función es para crear o mostrar arrays.
  Para poder usarlos en los ejercicios.
*/

/*
defino un struct porque no se me ocurrió
otra forma de devolver arrays en una funcion.
de paso le agrego len para guardar el tamaño usado.
*/
struct arreglo{
      int len;
      int arr[100];

};

/*la "funcion" toma un struct arreglo, en el que está el arreglo y su tamaño*/
struct arreglo crearArray(){
	int i=0;
	struct arreglo arreglo1;/*genera un "struct arreglo"*/
    int N;
	system("clear");/*(esta línea limpia la pantalla)*/
	printf("Cuantos elementos tendra el arreglo?\n");
	scanf("%d",&N);
	arreglo1.len=N;/*hace que el largo del struct arreglo sea N*/
    for(i ; i<N; i++){
    	system("clear");/*limpia pantalla*/
    	printf("\nIngrese el elemento de la posicion %d\n", i);
    	scanf("%d",&(arreglo1.arr)[i]);/*agrega a la posición i del
    	arreglo del struct arreglo lo que ingresa el usuario
    */}
    return arreglo1;/*devuelve el struct arreglo listo para usar*/
}

void mostrarArray(int arreglo[], int N){
    int i=0;
    for(i ; i<N; i++){
  	printf("\nPosicion %d: %d\n",i, arreglo[i]);/*muestra el número de posición
  	y el elemento en esa posición
  	*/
    }
    getchar();/*esto pausa la ejecución hasta presionar enter   */
    getchar();/*no es lo más correcto pero no encontré otra forma.*/
}


