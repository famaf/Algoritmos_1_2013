#include <stdio.h>
#include <stdlib.h>

/*Para variar un poco utilizamos el programa que calcula
el cubo de un número sólo con sumas
(del ejercicio 19.6 del libro)*/

int cuboDe(int b){
   int x=0,y=1,z=6,n=0;
   while (n!=b){
    x=x+y;
    y=y+z;
    z=z+6;
    n=n+1;}
    return x;}

/*Después el programa que calcula
el menor x tal que x^3+x>=n:*/
int minX(int N)
{
    int x=0;
    while (cuboDe(x)+x<N){/*mientras x^3+x sea menor que N se sigue incrementando x*/
    	x=x+1;
    }
	return x;
}

/*Finalmente la interfaz en el main:*/
int main()
{
	int n;
    system("clear");/*borra la pantalla*/
    printf("*********************************\n");
    printf("*   Minimo x tal que x^3+x>=N   *\n");
    printf("*********************************\n");
    printf("\nIngrese un numero: \n");
    scanf ("%d", &n);/*toma el valor ingrasado en la variable n*/
    printf("\nEl menor x tal que x^3+x>=%d es: %d\n\n",n,minX(n));/*devuelve el valor de minX evaluado en n*/
    getchar();/*pausa la ejecución para poder verel resultado*/
    getchar();
return 0;
}
