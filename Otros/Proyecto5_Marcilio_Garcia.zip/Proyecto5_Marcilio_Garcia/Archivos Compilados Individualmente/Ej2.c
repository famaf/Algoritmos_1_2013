#include <stdio.h>
#include <stdlib.h>



void suma (int arreglo[],int N){
    int r=0;
    int n=0;
    system ("clear");
    while (n<N){r=r+arreglo[n]; n=n+1;}
    printf("La suma de los elementos del arreglo es:%d\n",r);
    getchar();
    getchar();

}
int main(){
return 0;
}
