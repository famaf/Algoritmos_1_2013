#include <stdio.h>
#include <stdlib.h>

void prodPun(int arreglo1[],int arreglo2[], int N )
{
	int arreglo3[100];
	int n=0;
	system("clear");

	while (n<N){
		arreglo3[n]=arreglo1[n]*arreglo2[n];
		n=n+1;
	}
    printf("El arreglo resultante tiene los siguientes elementos:\n");
    n=0;
    while (n<N){
    printf("\nPosicion %d: %d\n",n, arreglo3[n]);
    n++;
    }
    getchar();
    getchar();
    }

int main (){
return 0;
}
