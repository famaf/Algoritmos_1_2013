#include <stdio.h>
#include <stdlib.h>


/*Como la asignación múltiple no es posible en c
agrego una variable z para guardar el valor
de r al iniciar el loop*/
int fibo(int N){
    int r=0,y=1,z=0,n=0;
    while (n<N){z=r;r=y;y=z+y;n++;}
    return r;

}
int main()
{
	int n;
	system("clear");
	printf("***************\n");
	printf("*  FIBONACCI  *\n");
	printf("***************\n");
	printf("\nIngrese un numero\n");
	scanf("%d",&n);
	printf("El FIBONACCI de %d es %d\n",n,fibo(n));
    getchar();
    getchar();
	return 0;
}
