#include <stdio.h>
#include <stdlib.h>

void posicion(int arreglo[], int N)
{
    int n=0;
   	int e;
   	system("clear");
   	printf("Escriba el elemento que desea buscar:\n");
   	scanf("%d",&e);
	while (n<N&&arreglo[n]!=e){
           n++;
	}
	if (n<N){printf("\nEl elemento esta en la posicion %d\n",n);}
		else {printf("\nEl elemento %d no esta en el arreglo.\n", e);}
        getchar();
        getchar();
}
int main (){
return 0;
}
