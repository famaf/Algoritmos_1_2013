#include <stdio.h>
#include <stdlib.h>

void mayor(int arreglo[],int N)
{
    int n=1;
    int r=arreglo[0];
    system("clear");
	if (N>0){
		while (n<N){
        if   (r>=arreglo[n]){n++;}
        else {r=arreglo[n];n++;}
         }
        printf("El mayor elemento del arreglo es %d\n",r);
   		}
       else{printf("El arreglo es vacío!!");}
        getchar();
        getchar();
}
int main(){
return 0;
}
