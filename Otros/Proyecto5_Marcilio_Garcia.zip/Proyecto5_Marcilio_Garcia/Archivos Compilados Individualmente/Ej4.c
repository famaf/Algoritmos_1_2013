#include <stdio.h>
#include <stdlib.h>

void pares(int arreglo[],int N)
{
	int n=0,r=0;
    system("clear");
	while (n<N){
		if (arreglo[n]%2==0){r=r+1;n++;}
			else{n++;}
	}
	printf("La cantidad de elementos pares del arreglo es: %d\n",r);
        getchar();
        getchar();
}
int main (){
return 0;
}
