#include <stdio.h>
#include <stdlib.h>

void positivos(int arreglo[], int N)
{
   	int n=0;
   	/*El bool no lo pude hacer de otra forma m�s que asign�ndole 1
   	o 0 a un int. Por eso la variable r figura como int*/
   	int r=1;
    system("clear");
    if(N>0){
	while (n<N&&r==1){
		   r=r&&arreglo[n]>0;
           n++;
	}
    if (r==1){
        printf("Todos los elementos del arreglo son mayores o iguales a cero.\n");
        }
        else {
        printf("No. Hay al menos un elemento negativo en el arreglo.\n");
        }
    }
        else {printf("El arreglo esta vacio!!");}
        getchar();
        getchar();

}
int main (){
return 0;
}
