#include <stdio.h>



float promedio(int arreglo[], int N){
    float prom=0;
    int n=0;
    while (n<N){
    prom = prom + arreglo[n];
    n++;
    }
    prom=prom/N;
    return prom;
}

void main5(int arreglo[], int N){
    float r=0;
    float xbarra=promedio(arreglo, N);
    int n=0;
    system("clear");
    while (n<N){
    	r=r+((arreglo[n]-xbarra)*(arreglo[n]-xbarra));
    	n++;
    }
        r=r/N;
    printf("La desviacion estandar del arreglo es:%g\n",r);

        getchar();
        getchar();
}






