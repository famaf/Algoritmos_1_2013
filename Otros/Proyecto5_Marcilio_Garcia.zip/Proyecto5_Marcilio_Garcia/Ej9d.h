#include <stdio.h>


void prodPun(int arreglo1[],int arreglo2[],int N )
{
	int arreglo3[N];
	int n=0,i=0;
	system("clear");

	while (n<N){
		arreglo3[n]=arreglo1[n]*arreglo2[n];/*a cada elemento de arreglo 3 le
		asigna la multiplicaci�n de los elementos de arreglo1 y arreglo2 de esa posici�n*/
		n=n+1;
	}
    printf("El arreglo resultante tiene los siguientes elementos:\n");
    for(i ; i<N; i++){
    printf("\nPosicion %d: %d\n",i, arreglo3[i]);/*da el n�mero de posici�n
  	y el elemento en esa posici�n
  	*/
    }
    getchar();
    getchar();
    }
