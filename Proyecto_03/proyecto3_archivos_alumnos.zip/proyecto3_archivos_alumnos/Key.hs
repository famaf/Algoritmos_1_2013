module Key ( Key, 
             key_MaxLen, 
             key_fromString, 
             key_toString,
             key_length
           ) 
where

data Key = Value String Int

-- M�ximo tama�o de la clave
key_MaxLen :: Int
key_MaxLen = undefined

-- De un string construye una clave
-- El tama�o del string debe ser menor o igual a key_MaxLen
key_fromString :: String -> Key
key_fromString = undefined

-- Convierte una clave a string
key_toString :: Key -> String
key_toString = undefined

-- Devuelve el tama�o de la clave
key_length :: Key -> Int
key_length = undefined

-- Las claves se pueden comparar
instance Eq Key where
    Value s1 l1 == Value s2 l2 = undefined

instance Ord Key where
    Value s1 l1 <= Value s2 l2 = undefined

