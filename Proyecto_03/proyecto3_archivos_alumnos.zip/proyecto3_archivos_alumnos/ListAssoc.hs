module ListAssoc ( ListAssoc, 
                   la_empty,
                   la_add, 
                   la_search, 
                   la_del, 
                   la_toListPair
                 )
where

data ListAssoc a b = Node a b (ListAssoc a b) | Empty

-- Lista de asociaciones vacia
la_empty :: ListAssoc a b
la_empty = undefined

-- Agrega un elemento a una lista de asociaciones
-- Si ya está, puede hacer cualquier cosa 
la_add :: a -> b -> ListAssoc a b -> ListAssoc a b
la_add = undefined

-- Devuelve el elemento asociado 
-- Si no está, devuelve Nothing
la_search :: Eq a => a -> ListAssoc a b -> Maybe b
la_search = undefined

-- Borra un elemento a la lista de asociaciones 
-- Si no está, no hace nada
la_del :: Eq a => a -> ListAssoc a b -> ListAssoc a b
la_del = undefined

-- Devuelve la lista de pares correspondiente a la lista de asociaciones
la_toListPair :: ListAssoc a b -> [(a,b)]
la_toListPair = undefined

