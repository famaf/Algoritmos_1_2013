module Data ( Data, 
              data_fromString, 
              data_toString,
              data_length
            )
where

data Data = Value String Int

-- De un string construye una Data
-- Almacena el tama�o
data_fromString :: String -> Data
data_fromString = undefined

-- Convierte una dato a string
data_toString :: Data -> String
data_toString = undefined

-- Devuelve el tama�o del dato
data_length :: Data -> Int
data_length = undefined

instance Show Data where
    show (Value s l) = undefined

