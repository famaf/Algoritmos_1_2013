module Abb ( Abb,
             abb_empty, 
             abb_add, 
             abb_search, 
             abb_del, 
             abb_toListPair)
where

data Abb a b = Rama a b (Abb a b) (Abb a b) | Hoja

-- Arbol vacio
abb_empty :: Abb a b
abb_empty = undefined

-- Agrega un elemento al abb
-- Si ya está, no lo agrega 
abb_add :: Ord a => a -> b -> Abb a b -> Abb a b
abb_add = undefined

-- Devuelve el elemento asociado 
-- Si no está, devuelve Nothing
abb_search :: Ord a => a -> Abb a b -> Maybe b
abb_search = undefined

-- Borra un elemento del arbol 
-- Si no está, no hace nada
abb_del :: Ord a => a -> Abb a b -> Abb a b
abb_del = undefined

-- Devuelve la lista de pares correspondiente de los elementos
-- almacenados en el arbol
abb_toListPair :: Abb a b -> [(a,b)]
abb_toListPair = undefined

