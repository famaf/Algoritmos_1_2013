module Dict ( Dict, 
              Word,
              Def,
              dict_empty, 
              dict_add, 
              dict_exist, 
              dict_search, 
              dict_del, 
              dict_length, 
              dict_toDefs )
where

import Data
import Key
import ListAssoc

data Dict = Dict Int (ListAssoc Key Data)

type Word = String
type Def  = String

-- Crea un diccionario vacio
dict_empty :: Dict
dict_empty = undefined

-- Pregunta si la clave esta en el diccionario
dict_exist :: Word -> Dict -> Bool
dict_exist = undefined
             {-   Ayuda:
               usar expresi�n `case ... of`
               <http://aprendehaskell.es/content/Funciones.html#expresiones-case>
             -}

-- Agrega un dato con una key al diccionario
-- Si la clave ya est�, no hace nada
dict_add :: Word -> Def -> Dict -> Dict
dict_add = undefined
           {- Ayuda: usar dict_exist en una guarda -}

-- Devuelve el dato asociado a un diccionario
-- Si no est�, devuelve Nothing
dict_search :: Word -> Dict -> Maybe Def
dict_search = undefined

-- Borra un dato del diccionario de acuerdo a una clave
-- Si la clave no est�, no hace nada
dict_del :: Word -> Dict -> Dict
dict_del = undefined

-- Devuelve la cantidad de datos en el diccionario
dict_length :: Dict -> Int
dict_length = undefined

-- Devuelve las definiciones del diccionario
dict_toDefs :: Dict -> [(Word,Def)]
dict_toDefs = undefined
              {- Ayuda: usar map con una funcion definida localmente -}
